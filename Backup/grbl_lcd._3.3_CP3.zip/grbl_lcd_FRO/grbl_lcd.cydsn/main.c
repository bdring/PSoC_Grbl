/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include "grbl.h"

// Declare system global variable structure
system_t sys; 



int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
   
    lcd_init();        
    serial_init();
    settings_init(); // Load Grbl settings from EEPROM
    stepper_init();
    system_init();
    
    memset(&sys, 0, sizeof(sys));  // Clear all system variables
    sys.abort = true;   // Set abort to complete initialization
    
    
    //move these to protocol_main_loop
    //report_init_message();   
    lcd_report_init_message();
    
    CyDelay(1000);
    LCD_WriteControl(LCD_CLEAR_DISPLAY);
    isr_LCD_Update_StartEx(ISR_lcd);
   
    // Check for power-up and set system alarm if homing is enabled to force homing cycle
    // by setting Grbl's alarm state. Alarm locks out all g-code commands, including the
    // startup scripts, but allows access to settings and internal commands. Only a homing
    // cycle '$H' or kill alarm locks '$X' will disable the alarm.
    // NOTE: The startup script will run after successful completion of the homing cycle, but
    // not after disabling the alarm locks. Prevents motion startup blocks from crashing into
    // things uncontrollably. Very bad.
    #ifdef HOMING_INIT_LOCK
    if (bit_istrue(settings.flags,BITFLAG_HOMING_ENABLE)) { sys.state = STATE_ALARM; }
    #endif

    // Force Grbl into an ALARM state upon a power-cycle or hard reset.
    #ifdef FORCE_INITIALIZATION_ALARM
    sys.state = STATE_ALARM;
    #endif

    
    
    
    for(;;)
    {
        /* Place your application code here. */
        // Reset Grbl primary systems.
        serial_reset_read_buffer(); // Clear serial read buffer
        gc_init(); // Set g-code parser to default state
        spindle_init();    
        coolant_init();       
        limits_init();      
        probe_init();
    
        plan_reset(); // Clear block buffer and planner variables
    
        st_reset(); // Clear stepper subsystem variables.
        
        
    

        // Sync cleared gcode and planner positions to current system position.
        plan_sync_position();
    
        gc_sync_position();

        // Reset system variables.
        sys.abort = false;
        sys_rt_exec_state = 0;
        sys_rt_exec_alarm = 0;
        sys.suspend = false;
         
    
        
        // Start Grbl main loop. Processes program inputs and executes them.
        protocol_main_loop();
    }
}

/* [] END OF FILE */
