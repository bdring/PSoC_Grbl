/*
  spindle_control.c - spindle control methods
  Part of Grbl

  Copyright (c) 2012-2015 Sungeun K. Jeon
  Copyright (c) 2009-2011 Simen Svale Skogsrud

  Grbl is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Grbl is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Grbl.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "grbl.h"



void spindle_init()
{    
  PWM_Spindle_Start();
  spindle_stop();
}


void spindle_stop()
{  
  PWM_Spindle_WriteCompare(0);
}


void spindle_set_state(uint8_t state, float rpm)
{
  if (sys.abort) { return; } // Block during abort.
  
  // Halt or set spindle direction and rpm. 
  if (state == SPINDLE_DISABLE) {

    spindle_stop();

  } 
    else 
  {

    uint8_t current_pwm;

      // Calculate PWM register value based on rpm max/min settings and programmed rpm.
      if (settings.rpm_max <= settings.rpm_min) {
        // No PWM range possible. Set simple on/off spindle control pin state.
        current_pwm = PWM_MAX_VALUE;
      } else {
        if (rpm > settings.rpm_max) { rpm = settings.rpm_max; }
        if (rpm < settings.rpm_min) { rpm = settings.rpm_min; }
        #ifdef SPINDLE_MINIMUM_PWM
          float pwm_gradient = (PWM_MAX_VALUE-SPINDLE_MINIMUM_PWM)/(settings.rpm_max-settings.rpm_min);
          current_pwm = floor( (rpm-settings.rpm_min)*pwm_gradient + (SPINDLE_MINIMUM_PWM+0.5));
        #else
          float pwm_gradient = (PWM_MAX_VALUE)/(settings.rpm_max-settings.rpm_min);
          current_pwm = floor( (rpm-settings.rpm_min)*pwm_gradient + 0.5);
        #endif
      }
      
      PWM_Spindle_WriteCompare(current_pwm);      
     
  }
}


void spindle_run(uint8_t state, float rpm)
{
  if (sys.state == STATE_CHECK_MODE) { return; }
  protocol_buffer_synchronize(); // Empty planner buffer to ensure spindle is set when programmed.  
  spindle_set_state(state, rpm);
}

