/*
  report.c - reporting and messaging methods
  Part of Grbl

  Copyright (c) 2012-2015 Sungeun K. Jeon  

  Grbl is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  Grbl is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with Grbl.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "grbl.h"

// Handles the primary confirmation protocol response for streaming interfaces and human-feedback.
// For every incoming line, this method responds with an 'ok' for a successful command or an 
// 'error:'  to indicate some error event with the line or some critical system error during 
// operation. Errors events can originate from the g-code parser, settings module, or asynchronously
// from a critical error, such as a triggered hard limit. Interface should always monitor for these
// responses.
// NOTE: In silent mode, all error codes are greater than zero.
// TODO: Install silent mode to return only numeric values, primarily for GUIs.

void get_state(char *foo)
{        
    // pad them to same length
    switch (sys.state) {
    case STATE_IDLE: strcpy(foo," Idle ");; break;
    case STATE_MOTION_CANCEL: // Report run state.
    case STATE_CYCLE: strcpy(foo," Run  "); break;
    case STATE_HOLD: strcpy(foo," Hold "); break;
    case STATE_HOMING: strcpy(foo," Home "); break;
    case STATE_ALARM: strcpy(foo," Alarm"); break;
    case STATE_CHECK_MODE: strcpy(foo," Check"); break;
    case STATE_SAFETY_DOOR: strcpy(foo," Door "); break;
    default:strcpy(foo,"  ?  "); break;
  }     
}





void report_status_message(uint8_t status_code) 
{
  

  if (status_code == 0) { // STATUS_OK
    UART_PutString("ok\r\n");
  } else {
    UART_PutString("error: ");
    #ifdef REPORT_GUI_MODE
      print_uint8_base10(status_code);
    #else
      switch(status_code) {          
        case STATUS_EXPECTED_COMMAND_LETTER:
       UART_PutString("Expected command letter"); break;
        case STATUS_BAD_NUMBER_FORMAT:
        UART_PutString("Bad number format"); break;
        case STATUS_INVALID_STATEMENT:
        UART_PutString("Invalid statement"); break;
        case STATUS_NEGATIVE_VALUE:
        UART_PutString("Value < 0"); break;
        case STATUS_SETTING_DISABLED:
        UART_PutString("Setting disabled"); break;
        case STATUS_SETTING_STEP_PULSE_MIN:
        UART_PutString("Value < 3 usec"); break;
        case STATUS_SETTING_READ_FAIL:
        UART_PutString("EEPROM read fail. Using defaults"); break;
        case STATUS_IDLE_ERROR:
        UART_PutString("Not idle"); break;
        case STATUS_ALARM_LOCK:
        UART_PutString("Alarm lock"); break;
        case STATUS_SOFT_LIMIT_ERROR:
        UART_PutString("Homing not enabled"); break;
        case STATUS_OVERFLOW:
        UART_PutString("Line overflow"); break;
        #ifdef MAX_STEP_RATE_HZ
          case STATUS_MAX_STEP_RATE_EXCEEDED: 
          UART_PutString("Step rate > 30kHz")); break;
        #endif
        case STATUS_CHECK_DOOR:
        UART_PutString("Check Door"); break;
        // Common g-code parser errors.
        case STATUS_GCODE_MODAL_GROUP_VIOLATION:
        UART_PutString("Modal group violation"); break;
        case STATUS_GCODE_UNSUPPORTED_COMMAND:
        UART_PutString("Unsupported command"); break;
        case STATUS_GCODE_UNDEFINED_FEED_RATE:
        UART_PutString("Undefined feed rate"); break;
        default:
          // Remaining g-code parser errors with error codes
          UART_PutString("Invalid gcode ID:");
          print_uint8_base10(status_code); // Print error code for user reference
      }
    #endif  
    UART_PutString("\r\n");
  }
}

// Prints alarm messages.
void report_alarm_message(int8_t alarm_code)
{
  UART_PutString("ALARM: ");
  #ifdef REPORT_GUI_MODE
    print_uint8_base10(alarm_code);
  #else
    switch (alarm_code) {
      case ALARM_HARD_LIMIT_ERROR: 
      UART_PutString("Hard limit"); break;
      case ALARM_SOFT_LIMIT_ERROR:
      UART_PutString("Soft limit"); break;
      case ALARM_ABORT_CYCLE: 
      UART_PutString("Abort during cycle"); break;
      case ALARM_PROBE_FAIL:
      UART_PutString("Probe fail"); break;
      case ALARM_HOMING_FAIL:
      UART_PutString("Homing fail"); break;
    }
  #endif
  UART_PutString("\r\n");
  delay_ms(500); // Force delay to ensure message clears serial write buffer.
}


// Prints feedback messages. This serves as a centralized method to provide additional
// user feedback for things that are not of the status/alarm message protocol. These are
// messages such as setup warnings, switch toggling, and how to exit alarms.
// NOTE: For interfaces, messages are always placed within brackets. And if silent mode
// is installed, the message number codes are less than zero.
// TODO: Install silence feedback messages option in settings
void report_feedback_message(uint8_t message_code)
{
  UART_PutString("[");
  switch(message_code) {
    case MESSAGE_CRITICAL_EVENT:
    UART_PutString("Reset to continue"); break;
    case MESSAGE_ALARM_LOCK:
    UART_PutString("'$H'|'$X' to unlock"); break;
    case MESSAGE_ALARM_UNLOCK:
    UART_PutString("Caution: Unlocked"); break;
    case MESSAGE_ENABLED:
    UART_PutString("Enabled"); break;
    case MESSAGE_DISABLED:
    UART_PutString("Disabled"); break; 
    case MESSAGE_SAFETY_DOOR_AJAR:
    UART_PutString("Check Door"); break;
    case MESSAGE_PROGRAM_END:
    UART_PutString("Pgm End"); break;
    case MESSAGE_RESTORE_DEFAULTS:
    UART_PutString("Restoring defaults"); break;
  }
  UART_PutString("]\r\n");
}

void report_init_message()
{       
  //UART_PutString("\r\n" GRBL_PORT " " GRBL_VERSION " ['$' for help]\r\n");
  UART_PutString("\r\nGrbl " GRBL_VERSION " ['$' for help]\r\n");
  
}



void report_grbl_settings() {
  // Print Grbl settings.
 
    
     UART_PutString("$0="); print_uint8_base10(settings.pulse_microseconds);
     UART_PutString(" (step pulse, usec)\r\n$1="); print_uint8_base10(settings.stepper_idle_lock_time);
     UART_PutString(" (step idle delay, msec)\r\n$2="); print_uint8_base10(settings.step_invert_mask); 
     UART_PutString(" (step port invert mask:"); print_uint8_base2(settings.step_invert_mask);  
     UART_PutString(")\r\n$3="); print_uint8_base10(settings.dir_invert_mask); 
     UART_PutString(" (dir port invert mask:"); print_uint8_base2(settings.dir_invert_mask);  
     UART_PutString(")\r\n$4="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_INVERT_ST_ENABLE));
     UART_PutString(" (step enable invert, bool)\r\n$5="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_INVERT_LIMIT_PINS));
     UART_PutString(" (limit pins invert, bool)\r\n$6="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_INVERT_PROBE_PIN));
     UART_PutString(" (probe pin invert, bool)\r\n$10="); print_uint8_base10(settings.status_report_mask);
     UART_PutString(" (status report mask:"); print_uint8_base2(settings.status_report_mask);
     UART_PutString(")\r\n$11="); printFloat_SettingValue(settings.junction_deviation);
     UART_PutString(" (junction deviation, mm)\r\n$12="); printFloat_SettingValue(settings.arc_tolerance);
     UART_PutString(" (arc tolerance, mm)\r\n$13="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_REPORT_INCHES));
     UART_PutString(" (report inches, bool)\r\n$20="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_SOFT_LIMIT_ENABLE));
     UART_PutString(" (soft limits, bool)\r\n$21="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_HARD_LIMIT_ENABLE));
     UART_PutString(" (hard limits, bool)\r\n$22="); print_uint8_base10(bit_istrue(settings.flags,BITFLAG_HOMING_ENABLE));
     UART_PutString(" (homing cycle, bool)\r\n$23="); print_uint8_base10(settings.homing_dir_mask);
     UART_PutString(" (homing dir invert mask:"); print_uint8_base2(settings.homing_dir_mask);  
     UART_PutString(")\r\n$24="); printFloat_SettingValue(settings.homing_feed_rate);
     UART_PutString(" (homing feed, mm/min)\r\n$25="); printFloat_SettingValue(settings.homing_seek_rate);
     UART_PutString(" (homing seek, mm/min)\r\n$26="); print_uint8_base10(settings.homing_debounce_delay);
     UART_PutString(" (homing debounce, msec)\r\n$27="); printFloat_SettingValue(settings.homing_pulloff);
     UART_PutString(" (homing pull-off, mm)\r\n$30="); printFloat_RPMValue(settings.rpm_max);
     UART_PutString(" (rpm max)\r\n$31="); printFloat_RPMValue(settings.rpm_min);
     UART_PutString(" (rpm min)\r\n");
    
    // Print axis settings
  uint8_t idx, set_idx;
  uint8_t val = AXIS_SETTINGS_START_VAL;
  for (set_idx=0; set_idx<AXIS_N_SETTINGS; set_idx++) {
    for (idx=0; idx<N_AXIS; idx++) {
      UART_PutString("$");
      print_uint8_base10(val+idx);
      UART_PutString("=");
      switch (set_idx) {
        case 0: printFloat_SettingValue(settings.steps_per_mm[idx]); break;
        case 1: printFloat_SettingValue(settings.max_rate[idx]); break;
        case 2: printFloat_SettingValue(settings.acceleration[idx]/(60*60)); break;
        case 3: printFloat_SettingValue(-settings.max_travel[idx]); break;
      }
      
        UART_PutString(" (");
        switch (idx) {
          case X_AXIS: UART_PutString("x"); break;
          case Y_AXIS: UART_PutString("y"); break;
          case Z_AXIS: UART_PutString("z"); break;
        }
        switch (set_idx) {
          case 0: UART_PutString(", step/mm"); break;
          case 1: UART_PutString(" max rate, mm/min"); break;
          case 2:UART_PutString(" accel, mm/sec^2"); break;
          case 3: UART_PutString(" max travel, mm"); break;
        }      
        UART_PutString(")\r\n");
     
    }
    val += AXIS_SETTINGS_INCREMENT;
  }
    
}

void report_grbl_help() {
  
    UART_PutString("$$ (view Grbl settings)\r\n"
                        "$# (view # parameters)\r\n"
                        "$G (view parser state)\r\n"
                        "$I (view build info)\r\n"
                        "$N (view startup blocks)\r\n"
                        "$x=value (save Grbl setting)\r\n"
                        "$Nx=line (save startup block)\r\n"
                        "$C (check gcode mode)\r\n"
                        "$X (kill alarm lock)\r\n"
                        "$H (run homing cycle)\r\n"
                        "~ (cycle start)\r\n"
                        "! (feed hold)\r\n"
                        "? (current status)\r\n"
                        "ctrl-x (reset Grbl)\r\n");
 
}

// Prints current probe parameters. Upon a probe command, these parameters are updated upon a
// successful probe or upon a failed probe with the G38.3 without errors command (if supported). 
// These values are retained until Grbl is power-cycled, whereby they will be re-zeroed.
void report_probe_parameters()
{
  uint8_t i;
  float print_position[N_AXIS];
 
  // Report in terms of machine position.
  UART_PutString("[PRB:");
  for (i=0; i< N_AXIS; i++) {
    print_position[i] = system_convert_axis_steps_to_mpos(sys.probe_position,i);
    printFloat_CoordValue(print_position[i]);
    if (i < (N_AXIS-1)) { UART_PutString(","); }
  }
  UART_PutString(":");
  print_uint8_base10(sys.probe_succeeded);
  UART_PutString("]\r\n");
}


// Prints Grbl NGC parameters (coordinate offsets, probing)
void report_ngc_parameters()
{
  float coord_data[N_AXIS];
  uint8_t coord_select, i;
  for (coord_select = 0; coord_select <= SETTING_INDEX_NCOORD; coord_select++) { 
    if (!(settings_read_coord_data(coord_select,coord_data))) { 
      report_status_message(STATUS_SETTING_READ_FAIL); 
      return;
    } 
    UART_PutString("[G");
    switch (coord_select) {
      case 6: UART_PutString("28"); break;
      case 7: UART_PutString("30"); break;
      default: print_uint8_base10(coord_select+54); break; // G54-G59
    }  
    UART_PutString(":");         
    for (i=0; i<N_AXIS; i++) {
      printFloat_CoordValue(coord_data[i]);
      if (i < (N_AXIS-1)) { UART_PutString(","); }
      else { UART_PutString("]\r\n"); }
    } 
  }
  UART_PutString("[G92:"); // Print G92,G92.1 which are not persistent in memory
  for (i=0; i<N_AXIS; i++) {
    printFloat_CoordValue(gc_state.coord_offset[i]);
    if (i < (N_AXIS-1)) { UART_PutString(","); }
    else { UART_PutString("]\r\n"); }
  } 
  UART_PutString("[TLO:"); // Print tool length offset value
  printFloat_CoordValue(gc_state.tool_length_offset);
  UART_PutString("]\r\n");
  report_probe_parameters(); // Print probe parameters. Not persistent in memory.
}

// Print current gcode parser mode state
void report_gcode_modes()
{
  UART_PutString("[");
  
  switch (gc_state.modal.motion) {
    case MOTION_MODE_SEEK : UART_PutString("G0"); break;
    case MOTION_MODE_LINEAR : UART_PutString("G1"); break;
    case MOTION_MODE_CW_ARC : UART_PutString("G2"); break;
    case MOTION_MODE_CCW_ARC : UART_PutString("G3"); break;
    case MOTION_MODE_NONE : UART_PutString("G80"); break;
    default: 
      UART_PutString("G38.");
      print_uint8_base10(gc_state.modal.motion - (MOTION_MODE_PROBE_TOWARD-2));
  }

  UART_PutString(" G");
  print_uint8_base10(gc_state.modal.coord_select+54);
  
  switch (gc_state.modal.plane_select) {
    case PLANE_SELECT_XY : UART_PutString(" G17"); break;
    case PLANE_SELECT_ZX : UART_PutString(" G18"); break;
    case PLANE_SELECT_YZ : UART_PutString(" G19"); break;
  }
  
  if (gc_state.modal.units == UNITS_MODE_MM) { UART_PutString(" G21"); }
  else { UART_PutString(" G20"); }
  
  if (gc_state.modal.distance == DISTANCE_MODE_ABSOLUTE) { UART_PutString(" G90"); }
  else { UART_PutString(" G91"); }
  
  if (gc_state.modal.feed_rate == FEED_RATE_MODE_INVERSE_TIME) { UART_PutString(" G93"); }
  else { UART_PutString(" G94"); }
    
  switch (gc_state.modal.program_flow) {
    case PROGRAM_FLOW_RUNNING : UART_PutString(" M0"); break;
    case PROGRAM_FLOW_PAUSED : UART_PutString(" M1"); break;
    case PROGRAM_FLOW_COMPLETED : UART_PutString(" M2"); break;
  }

  switch (gc_state.modal.spindle) {
    case SPINDLE_ENABLE_CW : UART_PutString(" M3"); break;
    case SPINDLE_ENABLE_CCW : UART_PutString(" M4"); break;
    case SPINDLE_DISABLE : UART_PutString(" M5"); break;
  }
  
  switch (gc_state.modal.coolant) {
    case COOLANT_DISABLE : UART_PutString(" M9"); break;
    case COOLANT_FLOOD_ENABLE : UART_PutString(" M8"); break;
    #ifdef ENABLE_M7
      case COOLANT_MIST_ENABLE : UART_PutString(" M7"); break;
    #endif
  }
  
  UART_PutString(" T");
  print_uint8_base10(gc_state.tool);
  
  UART_PutString(" F");
  printFloat_RateValue(gc_state.feed_rate);
  
  #ifdef VARIABLE_SPINDLE
    UART_PutString(" S");
    printFloat_RPMValue(gc_state.spindle_speed);
  #endif

  UART_PutString("]\r\n");
}

// Prints specified startup line
void report_startup_line(uint8_t n, char *line)
{
  UART_PutString("$N"); print_uint8_base10(n);
  UART_PutString("="); UART_PutString(line);
  UART_PutString("\r\n");
}


// Prints build info line
void report_build_info(char *line)
{
  UART_PutString("[" GRBL_VERSION "." GRBL_VERSION_BUILD ":");
  UART_PutString(line);
  UART_PutString("]\r\n");
 
}

// Prints the character string line Grbl has received from the user, which has been pre-parsed,
// and has been sent into protocol_execute_line() routine to be executed by Grbl.
void report_echo_line_received(char *line)
{
  UART_PutString("[echo: "); printString(line);
  UART_PutString("]\r\n");
}

// Prints real-time data. This function grabs a real-time snapshot of the stepper subprogram 
 // and the actual location of the CNC machine. Users may change the following function to their
 // specific needs, but the desired real-time data report must be as short as possible. This is
 // requires as it minimizes the computational overhead and allows grbl to keep running smoothly, 
 // especially during g-code programs with fast, short line segments and high frequency reports (5-20Hz).
void report_realtime_status()
{
  // **Under construction** Bare-bones status report. Provides real-time machine position relative to 
  // the system power on location (0,0,0) and work coordinate position (G54 and G92 applied). Eventually
  // to be added are distance to go on block, processed block id, and feed rate. Also a settings bitmask
  // for a user to select the desired real-time data.
  uint8_t idx;
  int32_t current_position[N_AXIS]; // Copy current state of the system position variable
  memcpy(current_position,sys.position,sizeof(sys.position));
  float print_position[N_AXIS];
 
  // Report current machine state
  switch (sys.state) {
    case STATE_IDLE: UART_PutString("<Idle"); break;
    case STATE_MOTION_CANCEL: // Report run state.
    case STATE_CYCLE: UART_PutString("<Run"); break;
    case STATE_HOLD: UART_PutString("<Hold"); break;
    case STATE_HOMING: UART_PutString("<Home"); break;
    case STATE_ALARM: UART_PutString("<Alarm"); break;
    case STATE_CHECK_MODE: UART_PutString("<Check"); break;
    case STATE_SAFETY_DOOR: UART_PutString("<Door"); break;
  }
 
  // If reporting a position, convert the current step count (current_position) to millimeters.
  if (bit_istrue(settings.status_report_mask,(BITFLAG_RT_STATUS_MACHINE_POSITION | BITFLAG_RT_STATUS_WORK_POSITION))) {
    system_convert_array_steps_to_mpos(print_position,current_position);
  }
  
  // Report machine position
  if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_MACHINE_POSITION)) {
    UART_PutString(",MPos:"); 
    for (idx=0; idx< N_AXIS; idx++) {
      printFloat_CoordValue(print_position[idx]);
      if (idx < (N_AXIS-1)) { UART_PutString(","); }
    }
  }
  
  // Report work position
  if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_WORK_POSITION)) {
    UART_PutString(",WPos:"); 
    for (idx=0; idx< N_AXIS; idx++) {
      // Apply work coordinate offsets and tool length offset to current position.
      print_position[idx] -= gc_state.coord_system[idx]+gc_state.coord_offset[idx];
      if (idx == TOOL_LENGTH_OFFSET_AXIS) { print_position[idx] -= gc_state.tool_length_offset; }    
      printFloat_CoordValue(print_position[idx]);
      if (idx < (N_AXIS-1)) { UART_PutString(","); }
    }
  }
        
  // Returns the number of active blocks are in the planner buffer.
  if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_PLANNER_BUFFER)) {
    UART_PutString(",Buf:");
    print_uint8_base10(plan_get_block_buffer_count());
  }

  // Report serial read buffer status
  if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_SERIAL_RX)) {
    UART_PutString(",RX:");
    print_uint8_base10(serial_get_rx_buffer_count());
  }
    
  //#ifdef USE_LINE_NUMBERS
    // Report current line number
    UART_PutString(",Ln:"); 
    int32_t ln=0;
    plan_block_t * pb = plan_get_current_block();
    if(pb != NULL) {
      ln = pb->line_number;
    } 
    printInteger(ln);
  //#endif
    
  #ifdef REPORT_REALTIME_RATE
    // Report realtime rate 
    UART_PutString(",F:"); 
    printFloat_RateValue(st_get_realtime_rate());
  #endif    
  
  #ifdef REPORT_ALL_PIN_STATES
    if (bit_istrue(settings.status_report_mask,
          ( BITFLAG_RT_STATUS_LIMIT_PINS| BITFLAG_RT_STATUS_PROBE_PIN | BITFLAG_RT_STATUS_CONTROL_PINS ))) {
      UART_PutString(",Pin:");
      if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_LIMIT_PINS)) { 
        print_unsigned_int8(limits_get_state(),2,N_AXIS);
      }
      UART_PutString("|");
      if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_PROBE_PIN)) {
        if (probe_get_state()) { UART_PutString("1"); }
        else { UART_PutString("0"); }
      }
      UART_PutString("|");
      if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_CONTROL_PINS)) {
        print_unsigned_int8(system_control_get_state(),2,N_CONTROL_PIN);
      }
    }
  #else
    if (bit_istrue(settings.status_report_mask,BITFLAG_RT_STATUS_LIMIT_PINS)) {
      UART_PutString(",Lim:"));
      print_unsigned_int8(limits_get_state(),2,N_AXIS);
    }
  #endif
  
 UART_PutString(">\r\n");
}


